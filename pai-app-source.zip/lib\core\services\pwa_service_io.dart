// Exportación condicional para plataformas no-web (IO)
export 'pwa_service_stub.dart';
