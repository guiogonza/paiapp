import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pai_app/core/theme/app_colors.dart';
import 'package:pai_app/data/repositories/trip_repository_impl.dart';
import 'package:pai_app/data/repositories/expense_repository_impl.dart';
import 'package:pai_app/data/repositories/vehicle_repository_impl.dart';
import 'package:pai_app/data/repositories/profile_repository_impl.dart';
import 'package:pai_app/domain/entities/trip_entity.dart';
import 'package:pai_app/domain/entities/expense_entity.dart';
import 'package:pai_app/domain/entities/vehicle_entity.dart';
import 'package:pai_app/domain/failures/trip_failure.dart';
import 'package:pai_app/presentation/pages/trips/trip_form_page.dart';
import 'package:pai_app/presentation/pages/trips/trip_detail_page.dart';

class TripsListPage extends StatefulWidget {
  const TripsListPage({super.key});

  @override
  State<TripsListPage> createState() => _TripsListPageState();
}

class _TripsListPageState extends State<TripsListPage> {
  final _repository = TripRepositoryImpl();
  final _expenseRepository = ExpenseRepositoryImpl();
  final _vehicleRepository = VehicleRepositoryImpl();
  final _profileRepository = ProfileRepositoryImpl();
  List<TripEntity> _allTrips = []; // Todos los viajes cargados
  List<TripEntity> _trips = []; // Viajes filtrados
  final Map<String, List<ExpenseEntity>> _expensesByTrip = {}; // tripId -> expenses
  bool _isLoading = true;
  TripFailure? _error;
  Map<String, VehicleEntity> _vehiclesById = {};
  bool _isCurrentUserDriver = false;
  String? _currentUserEmail;
  
  // Controladores de búsqueda
  final TextEditingController _searchController = TextEditingController();
  String _searchType = 'Todos'; // 'Todos', 'Origen', 'Destino', 'Cliente', 'Conductor'
  String? _selectedDriverFilter; // Para filtro por conductor (dropdown)
  List<String> _availableDrivers = []; // Lista de conductores con historial

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_applySearch);
    _loadTrips();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _updateAvailableDrivers(List<TripEntity> trips) {
    final driversSet = <String>{};
    for (var trip in trips) {
      if (trip.driverName.isNotEmpty) {
        driversSet.add(trip.driverName);
      }
    }
    setState(() {
      _availableDrivers = driversSet.toList()..sort();
    });
  }

  void _applySearch() {
    List<TripEntity> filtered = List.from(_allTrips);

    switch (_searchType) {
      case 'Origen':
        final query = _searchController.text.toLowerCase().trim();
        if (query.isNotEmpty) {
          filtered = filtered.where((trip) => 
            trip.origin.toLowerCase().contains(query)
          ).toList();
        }
        break;
      case 'Destino':
        final query = _searchController.text.toLowerCase().trim();
        if (query.isNotEmpty) {
          filtered = filtered.where((trip) => 
            trip.destination.toLowerCase().contains(query)
          ).toList();
        }
        break;
      case 'Cliente':
        final query = _searchController.text.toLowerCase().trim();
        if (query.isNotEmpty) {
          filtered = filtered.where((trip) => 
            trip.clientName.toLowerCase().contains(query)
          ).toList();
        }
        break;
      case 'Conductor':
        // Usar el dropdown seleccionado
        if (_selectedDriverFilter != null && _selectedDriverFilter!.isNotEmpty) {
          filtered = filtered.where((trip) => 
            trip.driverName == _selectedDriverFilter
          ).toList();
        }
        break;
      case 'Todos':
      default:
        final query = _searchController.text.toLowerCase().trim();
        if (query.isNotEmpty) {
          filtered = filtered.where((trip) => 
            trip.origin.toLowerCase().contains(query) ||
            trip.destination.toLowerCase().contains(query) ||
            trip.clientName.toLowerCase().contains(query) ||
            trip.driverName.toLowerCase().contains(query)
          ).toList();
        }
        break;
    }

    setState(() {
      _trips = filtered;
    });
  }

  Future<void> _loadTrips() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    await _loadCurrentUserRole();

    final result = await _repository.getTrips();

    result.fold(
      (failure) {
        setState(() {
          _error = failure;
          _isLoading = false;
        });
      },
      (trips) async {
        // Si el usuario es conductor, filtrar solo sus viajes
        List<TripEntity> filteredTrips = trips;
        if (_isCurrentUserDriver && _currentUserEmail != null) {
          filteredTrips = trips
              .where((trip) => trip.driverName == _currentUserEmail)
              .toList();
        }

        // Cargar vehículos una sola vez
        await _loadVehicles();

        if (mounted) {
          setState(() {
            _allTrips = filteredTrips;
            _trips = filteredTrips;
            _isLoading = false;
            _error = null;
          });
          // Obtener lista de conductores únicos de los viajes
          _updateAvailableDrivers(filteredTrips);
        }

        // Cargar gastos para todos los viajes visibles
        _loadExpensesForTrips(filteredTrips);
      },
    );
  }

  Future<void> _loadCurrentUserRole() async {
    try {
      final profileResult = await _profileRepository.getCurrentUserProfile();
      profileResult.fold(
        (failure) {
          _isCurrentUserDriver = false;
          _currentUserEmail = null;
        },
        (profile) {
          _isCurrentUserDriver = profile.role == 'driver';
          _currentUserEmail = profile.email;
        },
      );
    } catch (_) {
      _isCurrentUserDriver = false;
      _currentUserEmail = null;
    }
  }

  Future<void> _loadVehicles() async {
    final result = await _vehicleRepository.getVehicles();
    result.fold(
      (failure) {
        // No bloquear por error de vehículos, solo no mostrar placa
        _vehiclesById = {};
      },
      (vehicles) {
        final map = <String, VehicleEntity>{};
        for (final vehicle in vehicles) {
          if (vehicle.id != null) {
            map[vehicle.id!] = vehicle;
          }
        }
        _vehiclesById = map;
      },
    );
  }

  Future<void> _handleDelete(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Eliminar viaje'),
        content: const Text('¿Estás seguro de que deseas eliminar este viaje?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final result = await _repository.deleteTrip(id);

    result.fold(
      (failure) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(failure.message),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      },
      (_) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Viaje eliminado exitosamente'),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
          ),
        );
        _loadTrips();
      },
    );
  }

  Future<void> _loadExpensesForTrips(List<TripEntity> trips) async {
    for (final trip in trips) {
      if (trip.id == null) continue;
      
      try {
        final expensesResult = await _expenseRepository.getExpensesByTripId(trip.id!);
        
        expensesResult.fold(
          (failure) {
            // Ignorar errores, simplemente no mostrar gastos
          },
          (expenses) {
            if (mounted) {
              setState(() {
                _expensesByTrip[trip.id!] = expenses;
              });
            }
          },
        );
      } catch (e) {
        // Ignorar errores
      }
    }
  }

  String _buildVehicleLabel(String vehicleId) {
    final vehicle = _vehiclesById[vehicleId];
    if (vehicle == null) {
      return '-';
    }
    return vehicle.placa;
  }

  double _getTotalExpenses(String? tripId) {
    if (tripId == null || !_expensesByTrip.containsKey(tripId)) {
      return 0.0;
    }
    return _expensesByTrip[tripId]!.fold<double>(
      0.0,
      (sum, expense) => sum + expense.amount,
    );
  }

  double _calculateProfit(TripEntity trip) {
    return trip.revenueAmount - _getTotalExpenses(trip.id);
  }

  String _formatCurrency(double amount) {
    final formatter = NumberFormat.currency(
      symbol: '\$',
      decimalDigits: 0,
      locale: 'es_CO',
    );
    return formatter.format(amount);
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'No especificada';
    return DateFormat('dd/MM/yyyy').format(date);
  }

  String _getSearchHint() {
    switch (_searchType) {
      case 'Origen':
        return 'Buscar por origen...';
      case 'Destino':
        return 'Buscar por destino...';
      case 'Cliente':
        return 'Buscar por cliente...';
      case 'Conductor':
        return 'Buscar por conductor...';
      case 'Todos':
      default:
        return 'Buscar en origen, destino, cliente o conductor...';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Viajes'),
      ),
      body: Column(
        children: [
          // Barra de búsqueda
          Container(
            padding: const EdgeInsets.all(16.0),
            color: AppColors.background,
            child: Column(
              children: [
                // Selector de tipo de búsqueda
                DropdownButtonFormField<String>(
                  initialValue: _searchType,
                  decoration: InputDecoration(
                    labelText: 'Buscar por',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'Todos', child: Text('Todos los campos')),
                    DropdownMenuItem(value: 'Origen', child: Text('Origen')),
                    DropdownMenuItem(value: 'Destino', child: Text('Destino')),
                    DropdownMenuItem(value: 'Cliente', child: Text('Cliente')),
                    DropdownMenuItem(value: 'Conductor', child: Text('Conductor')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _searchType = value;
                        if (value != 'Conductor') {
                          _selectedDriverFilter = null;
                        }
                      });
                      _applySearch();
                    }
                  },
                ),
                const SizedBox(height: 12),
                // Campo de búsqueda o dropdown de conductores
                _searchType == 'Conductor'
                    ? DropdownButtonFormField<String>(
                        initialValue: _selectedDriverFilter,
                        decoration: InputDecoration(
                          labelText: 'Seleccionar conductor',
                          prefixIcon: const Icon(Icons.person),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        ),
                        items: [
                          const DropdownMenuItem(
                            value: null,
                            child: Text('Todos los conductores'),
                          ),
                          ..._availableDrivers.map((driver) {
                            return DropdownMenuItem(
                              value: driver,
                              child: Text(driver),
                            );
                          }),
                        ],
                        onChanged: (value) {
                          setState(() {
                            _selectedDriverFilter = value;
                          });
                          _applySearch();
                        },
                      )
                    : TextField(
                        controller: _searchController,
                        decoration: InputDecoration(
                          hintText: _getSearchHint(),
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: _searchController.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(Icons.clear),
                                  onPressed: () {
                                    _searchController.clear();
                                    _applySearch();
                                  },
                                )
                              : null,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        ),
                        onChanged: (_) => _applySearch(),
                      ),
              ],
            ),
          ),
          // Lista de viajes
          Expanded(
            child: RefreshIndicator(
              onRefresh: _loadTrips,
              child: _buildBody(),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.of(context).push<TripEntity>(
            MaterialPageRoute(
              builder: (_) => const TripFormPage(),
            ),
          );

          if (result != null) {
            _loadTrips();
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('Agregar Viaje'),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline,
                size: 64,
                color: Colors.red[300],
              ),
              const SizedBox(height: 16),
              Text(
                _error!.message,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _loadTrips,
                icon: const Icon(Icons.refresh),
                label: const Text('Reintentar'),
              ),
            ],
          ),
        ),
      );
    }

    if (_trips.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.route_outlined,
                size: 80,
                color: AppColors.textSecondary.withOpacity(0.5),
              ),
              const SizedBox(height: 16),
              Text(
                'No tienes viajes aún',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: AppColors.textSecondary,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Toca el botón + para agregar tu primer viaje',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: AppColors.textSecondary,
                    ),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _trips.length,
      itemBuilder: (context, index) {
        final trip = _trips[index];
        final vehicleLabel = _buildVehicleLabel(trip.vehicleId);
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            onTap: () {
              if (trip.id != null) {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => TripDetailPage(tripId: trip.id!),
                  ),
                );
              }
            },
              leading: CircleAvatar(
                backgroundColor: AppColors.accent.withOpacity(0.2),
                child: Icon(
                  Icons.route,
                  color: AppColors.accent,
                ),
              ),
            title: Text(
              trip.driverName,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                // Vehículo
                Text(
                  'Vehículo: $vehicleLabel',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 4),
                // Origen - Destino
                Text(
                  '${trip.origin} → ${trip.destination}',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                // Ingreso, Gastos y Resultado
                Column(
                  children: [
                    // Ingreso
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.trending_up,
                            size: 16,
                            color: Colors.green[700],
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Ingreso: ${_formatCurrency(trip.revenueAmount)}',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.green[700],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    // Gastos Totales
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.receipt_long,
                            size: 16,
                            color: Colors.orange[700],
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Gastos: ${_formatCurrency(_getTotalExpenses(trip.id))}',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.orange[700],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    // Resultado
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: _calculateProfit(trip) >= 0
                            ? Colors.green.withOpacity(0.2)
                            : Colors.red.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _calculateProfit(trip) >= 0
                                ? Icons.trending_up
                                : Icons.trending_down,
                            size: 16,
                            color: _calculateProfit(trip) >= 0
                                ? Colors.green[700]
                                : Colors.red[700],
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Resultado: ${_formatCurrency(_calculateProfit(trip))}',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: _calculateProfit(trip) >= 0
                                  ? Colors.green[700]
                                  : Colors.red[700],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                if (trip.startDate != null || trip.endDate != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    'Inicio: ${_formatDate(trip.startDate)}',
                    style: TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  Text(
                    'Fin: ${_formatDate(trip.endDate)}',
                    style: TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ],
            ),
            trailing: PopupMenuButton(
              icon: const Icon(Icons.more_vert),
              itemBuilder: (context) => [
                PopupMenuItem(
                  child: const Row(
                    children: [
                      Icon(Icons.edit, size: 20),
                      SizedBox(width: 8),
                      Text('Editar'),
                    ],
                  ),
                  onTap: () async {
                    await Future.delayed(const Duration(milliseconds: 100));
                    if (context.mounted) {
                      final result =
                          await Navigator.of(context).push<TripEntity>(
                        MaterialPageRoute(
                          builder: (_) => TripFormPage(trip: trip),
                        ),
                      );

                      if (result != null && mounted) {
                        _loadTrips();
                      }
                    }
                  },
                ),
                PopupMenuItem(
                  child: const Row(
                    children: [
                      Icon(Icons.delete, size: 20, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Eliminar', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                  onTap: () {
                    _handleDelete(trip.id!);
                  },
                ),
              ],
            ),
            isThreeLine: true,
          ),
        );
      },
    );
  }
}

