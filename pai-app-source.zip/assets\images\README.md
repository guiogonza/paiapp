# Logo PPAI

Por favor, coloca aquí la imagen del logo PPAI con el nombre:

**`ppai_logo.png`**

La imagen se usará en:
- Login Page (con fondo blanco, width: 200.0px)
- Splash Page (con fondo azul del manual de marca, width: 200.0px)

**INSTRUCCIONES:**
1. Renombra tu archivo de imagen a: `ppai_logo.png`
2. Colócalo en esta carpeta: `assets/images/`
3. La imagen debe ser PNG con fondo transparente

