import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:pai_app/core/theme/app_colors.dart';
import 'package:pai_app/data/repositories/auth_repository_impl.dart';
import 'package:pai_app/data/repositories/profile_repository_impl.dart';
import 'package:pai_app/presentation/pages/owner/owner_dashboard_page.dart';
import 'package:pai_app/presentation/pages/driver/driver_dashboard_page.dart';
import 'package:pai_app/presentation/widgets/pwa_install_prompt.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _authRepository = AuthRepositoryImpl();
  bool _isLoading = false;
  bool _obscurePassword = true;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  /// Construye el logo PPAI con imagen corporativa (tamaño compacto)
  Widget _buildPpaiLogo() {
    return Image.asset(
      'assets/images/ppai_logo.png',
      height: 160,
      fit: BoxFit.contain,
      errorBuilder: (context, error, stackTrace) {
        // Si la imagen no existe, mostrar mensaje de ayuda
        debugPrint('Error cargando logo: $error');
        return const SizedBox(
          height: 160,
          child: Center(
            child: Icon(
              Icons.image_not_supported,
              size: 32,
              color: AppColors.textSecondary,
            ),
          ),
        );
      },
    );
  }

  Future<void> _handleLogin() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      await _authRepository.login(
        _usernameController.text.trim(),
        _passwordController.text,
      );

      if (mounted) {
        _navigateToDashboard();
      }
    } catch (e) {
      if (mounted) {
        String errorMessage = e.toString().replaceFirst('Exception: ', '');
        
        // Mensajes más amigables para errores comunes
        if (errorMessage.contains('ERR_NAME_NOT_RESOLVED') || 
            errorMessage.contains('Failed to load resource') ||
            errorMessage.contains('network') ||
            errorMessage.contains('connection')) {
          errorMessage = 'Error de conexión. Verifica tu internet y que puedas acceder a Supabase.';
        } else if (errorMessage.contains('Invalid login credentials') ||
                   errorMessage.contains('Credenciales inválidas')) {
          errorMessage = 'Usuario o contraseña incorrectos. Verifica tus credenciales.';
        } else if (errorMessage.contains('User not found')) {
          errorMessage = 'Usuario no encontrado. Verifica tu usuario o regístrate primero.';
        }
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errorMessage),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _navigateToDashboard() async {
    try {
      final profileRepository = ProfileRepositoryImpl();
      final profileResult = await profileRepository.getCurrentUserProfile();
      
      if (mounted) {
        profileResult.fold(
          (failure) {
            // Si no se puede obtener el perfil, mostrar OwnerDashboardPage por defecto
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (_) => const OwnerDashboardPage()),
            );
          },
          (profile) {
            // Redirigir según el role
            Widget targetPage;
            if (profile.role == 'owner' || profile.role == 'super_admin') {
              // super_admin tiene acceso completo como owner
              targetPage = const OwnerDashboardPage();
            } else if (profile.role == 'driver') {
              targetPage = const DriverDashboardPage();
            } else {
              // Role desconocido, mostrar OwnerDashboardPage por defecto
              targetPage = const OwnerDashboardPage();
            }
            
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (_) => targetPage),
            );
          },
        );
      }
    } catch (e) {
      // Error al obtener perfil, mostrar OwnerDashboardPage por defecto
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const OwnerDashboardPage()),
        );
      }
    }
  }

  Future<void> _handleRegister() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      await _authRepository.register(
        _usernameController.text.trim(),
        _passwordController.text,
      );

      // Después del registro, intentar hacer login automáticamente
      try {
        await _authRepository.login(
          _usernameController.text.trim(),
          _passwordController.text,
        );

        if (mounted) {
          _navigateToDashboard();
        }
      } catch (loginError) {
        // Si el login falla (por ejemplo, si requiere confirmación de email),
        // mostrar mensaje pero permitir que el usuario intente iniciar sesión manualmente
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text(
                'Registro exitoso. Por favor, inicia sesión con tus credenciales.',
              ),
              backgroundColor: Colors.orange,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 5),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        final errorMessage = e.toString().replaceFirst('Exception: ', '');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errorMessage),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Logo PPAI
                  _buildPpaiLogo(),
                  const SizedBox(height: 8),
                  Text(
                    'TECNOLOGÍA A TU ALCANCE',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w300,
                      color: AppColors.textSecondary,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 32),
                  // Usuario Field
                  TextFormField(
                    controller: _usernameController,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      labelText: 'Usuario',
                      prefixIcon: const Icon(Icons.person_outlined),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      helperText: 'Puede ser cualquier texto (email, nombre, etc.)',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor ingresa tu usuario';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  // Password Field
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _obscurePassword,
                    textInputAction: TextInputAction.done,
                    onFieldSubmitted: (_) => _handleLogin(),
                    decoration: InputDecoration(
                      labelText: 'Contraseña',
                      prefixIcon: const Icon(Icons.lock_outlined),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                        ),
                        onPressed: () {
                          setState(() {
                            _obscurePassword = !_obscurePassword;
                          });
                        },
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor ingresa tu contraseña';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 24),
                  // Login Button
                  SizedBox(
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _handleLogin,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: AppColors.textOnPrimary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 2,
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              height: 24,
                              width: 24,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                    AlwaysStoppedAnimation<Color>(Colors.white),
                              ),
                            )
                          : const Text(
                              'INGRESAR',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Register Link
                  TextButton(
                    onPressed: _isLoading ? null : _handleRegister,
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: TextStyle(
                          fontSize: 14,
                          color: AppColors.textSecondary,
                        ),
                        children: [
                          const TextSpan(text: '¿No tienes cuenta? '),
                          TextSpan(
                            text: 'Regístrate',
                            style: TextStyle(
                              color: AppColors.accent,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // PWA Install Button
                  if (kIsWeb) ...[
                    const SizedBox(height: 24),
                    OutlinedButton.icon(
                      onPressed: () => PWAInstallPrompt.showInstallDialog(context),
                      icon: const Icon(Icons.install_mobile),
                      label: const Text('Instalar App'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        side: BorderSide(color: AppColors.accent),
                        foregroundColor: AppColors.accent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


